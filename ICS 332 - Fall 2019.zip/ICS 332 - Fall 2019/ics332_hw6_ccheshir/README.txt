ICS 332, Fall 2019 - HW 6 - Christian Cheshire
13 Nov 2019

Question #1

Assuming that it allocates at the beginning, the 480-byte chunk
would be allocated at address 2112. But that doesn't work because 
it was allocated at address 2624 - 480 = 2144, which means it was
allocated at the end of the second hole. Thus, we can conclude that
the allocator allocates chunks at the end of holes.


Question #2

Worst fit. 

The allocator allocates the 100-byte chunk at address 2524, the 512-byte hole. 
That is the first hole which is big enough, and is the biggest hole.

It allocates the 200-byte chunk at address 2324, the 512-100 = 412-byte hole. 
That is the first hole which is big enough, and is the biggest hole.

It allocates the 100-byte chunk at address 2224, the 412-200 = 212-byte hole.
That is the first hole which is big enough, and is the biggest hole.

It allocates the 80-byte chunk at address 3696, the 128-byte hole.
That is not the first hole which is big enough (which is 112-bytes), but it is the biggest hole.

Which means it cannot be first fit and must be worst fit.


Question #3

None of the above.

The allocator allocates the 40-byte chunk to the 128-byte hole.
That is not the first hole which is big enough, 
is not the biggest hole, 
and is not the smallest hole that is big enough. 

It allocates the 400-byte chunk to the 512-byte hole.
That is the first hole which is big enough and is the biggest hole.

It allocates the 80-byte chunk to the 512-400=112-byte hole.
That is the first hole which is big enough and is the biggest hole remaining.

It allocates the 60-byte chunk to the second 64-byte hole.
That is not the first hole which is big enough and is the biggest hole remaining.

So, just based off of the first chunk assignment, we can see that it is none of the above.


Question #4

0 | 1024 | 1088 | 2112 | 2624 | 3648 | 3776 | 4800 | 4864 |
--------------
The 400-byte chunk was allocated at address 2224 (because the largest hole is 512-bytes)
The 100-byte chunk was allocated at address 3676 (because the largest hole remaining is 128-bytes)
The 10-byte chunk was allocated at address 2214 (because the largest hole remaining is 512-400 = 112-bytes)
The 10-byte chunk was allocated at address 2204 (because the largest hole remaining is 112-10 = 102-bytes)