ICS 332, Fall 2019 - Assignment 5 - Christian Cheshire

Exercise #1
---------------------

Question #1

[q1] It is job B because it continues to return to the ready queue before C and D, and thus runs before them using the full time quantum and then being kicked off.
     While D also runs for the full time quantum, it doesn't return directly to the ready queue (which means it's doing I/O) and can't have an infinitely long CPU burst.

[q2] Job D has the longest I/O burst because it has the longest time period between instances of going to the CPU.

[q3] Job A is the text editor because it spends a lot of time doing I/O and goes to the CPU for short bursts. It's CPU burst lengths vary due to user input. 

Question #2

[q1] Io IoIoIoCCCo IoIoIoCCCo IoIoIoCCCo IoIoIoCCCo IoIoIoCCCo
     This overall sequence will repeat again by starting with the four I/O jobs.
     The basic repeating sequence is IoIoIoCCCo.

[q2] The total time for CPU and context-switching overhead is 33.1 ms, after which the overall sequence repeats. 
     During this period, each I/O bound job runs for a total of 4ms on the CPU and 16ms for I/O. This makes a total of 16 + 4 = 20ms. The rest of the time is in the ready state. 
     Thus, 33.1 - 20 = 11.1ms. Then, dividing by the number of I/O bound jobs we get (11.1)/4 = 2.78ms.
     This means on average the I/O bound jobs spend 2.78ms in the ready state during the entire period of the overall sequence.

[q3] There are 21 context-switches in this sequence.
     If we set the context-switch time to 0.03 ms, we find 0.03*21 = 0.63 ms.
     And 0.63 is ~2% of 31 + 0.63 = 31.63 ms (CPU time plus new context-switch time).
     So, the answer is ~0.03 ms.


Exercise #2
---------------------

Question #1

[q1] Job A will end up in the mid-priority queue because it uses the full time quantum of 4ms.
     Job B will remain in the high-priority queue because it doesn't use the full time quantum of 4ms.
     Job C will end up in the mid-priority queue because it uses the full time quantum of 4ms.
     Job D will end up in the low-priority queue because it uses the full time quantum of 4ms and uses the full time quantum of 8ms.
     Job E will end up in the low-priority queue because it uses the full time quantum of 4ms, uses the full time quantum of 8ms,
     and uses the full time quantum of 20ms but there isn't a lower queue for it to go to.     

[q2] AAAA BB CCCC DDDD EEEE
     Thus, D is placed in the mid-priority queue at time 14ms because it has run for the full time quantum of 4ms.

Question #2

[q1] AA BBBB AA B AA B ...

[q2] Yes, in the long-run job B will run about 1/3 of the time because job A goes to I/O for 1ms after each CPU burst of 2ms.

[q3] AA BBBB AA B AA B AA BBBB AA B AA B AA BBBB AA B AA B AA BBB ...