ICS 332 - Assignment 4 - Christian Cheshire
17 Oct 2019

Exercise #1
-------------------
Question #1: Value found for the graph size was 150, which ran in approximately 27 seconds.

Question #3: 

Average execution times (seconds)

1 thread: 28.139
2 threads: 19.592
3 threads: 19.815
4 threads: 19.783
5 threads: 20.815
6 threads: 19.817
7 threads: 19.662
8 threads: 19.157
9 threads: 19.650
10 threads: 19.293

[q1] It runs about 1.4x faster (i.e. 19.592 * 1.4 = approximately 27)

[q2] My machine has four physical cores.

[q3] Using more threads than the number of physical cores was not useful. 
     After increasing the number of threads to two, the time improved significantly. 
     However, beyond two threads there was minimal change.

[q4] The largest acceleration factor was between using one and two threads. 
     The difference was 8.547 seconds, but after that had a difference of around 0.4 to 1.3 seconds.
     Overall, the time when using more threads remained relatively constant around 19 seconds, although there was a bit of a jump for five threads to 20.815 seconds.