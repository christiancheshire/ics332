// ICS 332 - Assignment 4 - Christian Cheshire - 17 Oct 2019
// ComputePaths implements the ability to specify the number of threads, based off of provided starter code

package paths;

public class ComputePaths {

    // ADDED WORKER CLASS

    public class Worker implements Runnable {
	int size;
	int start;
	int end;
        
        public Worker(int start, int end, int size) { 
		this.start = start;
		this.end = end;
		this.size = size;
	}

	@Override
	public void run() {
		for (int i = start; i < end; i++) {
			new FloydWarshall(size, i).floydWarshall();
		}
	}
    }

    public void compute(int graph_size, int num_threads) {

	// BEGIN ADDED CODE

	Thread theThread[] = new Thread[num_threads];
	
	if (num_threads !=1) {
		int count = 0;
		int rangeTemp = 0;
		int[] range = new int[num_threads];
		int temp = 2520/num_threads;
		int i = 0;
		range[0] = temp;

		while (count != num_threads -1) {
			rangeTemp = temp + rangeTemp;
			range[count] = rangeTemp;
			count ++;
		}

		for (i = 0; i < num_threads; i++) {
			theThread[i] = new Thread(new Worker(range[i], range[i] + temp, graph_size));
			theThread[i].start();
		}

		i = 0;
		
		while (i < num_threads) {
			try {
				theThread[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			i++;
		}
	} else {

	// END ADDED CODE

        	for (long i = 0; i < 2520; i++) {
            		new FloydWarshall(graph_size, i).floydWarshall();
        	}
	}

    }

    public static void main(String[] args) {

        if (args.length != 2) {
            System.err.println("Usage: java ComputePaths <graph size> <# threads>");
            System.exit(1);
        }

        int graph_size = 0;
        int num_threads = 0;
        try {
            graph_size = Integer.parseInt(args[0]);
            num_threads = Integer.parseInt(args[1]);
            if ((graph_size <= 0) || (num_threads < 1)) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid command-line arguments");
            System.exit(1);
        }

        double now = System.currentTimeMillis();

        new ComputePaths().compute(graph_size, num_threads);

        System.out.println("All graphs computed in " + (System.currentTimeMillis() - now) / 1000 + " seconds");

    }

}
