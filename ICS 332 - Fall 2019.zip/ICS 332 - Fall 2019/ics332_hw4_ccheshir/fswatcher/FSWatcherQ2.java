// ICS332 Fall 2019 - Assignment 4 - Christian Cheshire - 17 Oct 2019
// Improves previous FSWatcher class to watch multiple directories

package fswatcher;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class FSWatcherQ2 {

     class Reader implements Runnable {

        Consumer<String> method;
    	BufferedReader stdout;

        Reader(Consumer<String> temp, BufferedReader input) {
            this.method = temp;
            this.stdout = input;
        }
        
	@Override
        public void run() {

        	String output_line = "";

            	while (true) {
            		try {
                    		output_line = stdout.readLine();
            		} catch (IOException e) {
                		System.err.println(e.getMessage());
                		System.exit(1);
            		}
            
			if (output_line == null) {
                		break;
            		} else {
                    		method.accept(output_line);
            		}
            	}
        }
    }

    public void watch(String dirname, Consumer<String> method) {
	
        String[] tokens = ("inotifywait -e create -m " + dirname).split("[ \t\n]+");
        
	Process p = null;
        ProcessBuilder pb = new ProcessBuilder(tokens);
        
	try {
            p = pb.start();
        } catch (IOException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        
	InputStream sstdout = p.getInputStream();
        BufferedReader stdout = new BufferedReader(new InputStreamReader(sstdout));
    	Reader myReader = new Reader(method, stdout);
    	Thread myThread = new Thread(myReader);
    	myThread.start();
    }
}