ICS 332 - HW9 - Fall 2019
Christian Cheshire
10 Dec 2019

Question F.q1.20 [10 pts]

20 * (2000 / 125) + 3600 + 20 * (2000 / 1250) + 20 * (2000 / 1250) + 300 + (2000 / 125) = 4300s
The simulation runs in 4316.842434s which is close to our expected value.


Question F.q1.21 [5 pts]

Simulated time in q1.16 was 15116.884782s.
Which means that the answer in q1.20 of 4316.842434s is (15116.884782 / 4316.842434) = 3.5 
So, it is approximately 3.5 times faster.


Question F.q1.22 [10 pts]

((20*3600) + (1*300)) / (32 * 4316.842) = 0.5234
So, the parallel efficiency is approximately 52%.


Question F.q1.23 [10 pts]

It would have been: 
((20*3600) + (1*300)) / (20 * 4316.842) = 0.8374
Which is approximately 84%.


Question F.q1.24 [5 pts]

No, because there is already one core to run each task when we have 4 nodes with 5 cores each (4 * 5 = 20).
Anything more than that isn't useful because we just waste space.


Question F.q1.25 [10 pts] [EXTRA CREDIT]

Seven, because with 7 nodes of 3 cores each there will be 21 cores and all 20 tasks can be run simultaneously.