// ICS332 Fall 2019 - Assignment 3 - Christian Cheshire
// FSWatcherQ1 provides watch() method for FSWatcherUseCaseQ1

package fswatcher;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class FSWatcherQ1 {

    // Uses linux inotifywait
    public void watch(String dirname, Consumer<String> method) {
        
	String[] tokens = ("inotifywait -e create -m " + dirname).split("[ \t\n]+");
        
	Process p = null;
        
	ProcessBuilder pb = new ProcessBuilder(tokens);

      	try {
		// Start process inotifywait
    		p = pb.start();
        } catch (IOException e) {
            	System.err.println(e.getMessage());
            	System.exit(1);
        }
        
	String output_line = "";

	// To read output
        BufferedReader stdout = new BufferedReader(new InputStreamReader(p.getInputStream()));

        while (true) {
	
        	try {
			// Get output of inotifywait
                	output_line = stdout.readLine();
        	} catch(IOException e) {
            		System.err.println(e.getMessage());
        		System.exit(1);
        	}

        	if (output_line == null) {
            		break;
        	} else {
			// Provide output to method
                	method.accept(output_line);
        	}
        }
     }
}