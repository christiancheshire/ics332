// ICS332 Fall 2019 - Assignment 3 - Christian Cheshire
// KVServer2 implements KVInterface in a way that avoids starting rmiregistry manually. Methods implemented by me based on starter material.

package kvstore;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.InterruptedException;

public class KVServer2 extends UnicastRemoteObject implements KVInterface {

    private static final String serverName = "rmi://localhost/Server";

    // Custom constructor that throws the required exception
    protected KVServer2() throws RemoteException {
        super();
    }

    // Create a new hashmap
    HashMap<String,String> hm = new HashMap<String,String>();

    @Override
    public void insert(String key, String value) throws RemoteException {

	// If the key already exists in the table, replace the value for that key
	if (hm.containsKey(key) == true) {
		hm.replace(key,value);
	}else{	
		// Otherwise, insert the key and value			
		hm.put(key,value);
	}
    }

    @Override
    public String lookup(String key) throws RemoteException, KeyNotFound {
       	
	// If the key exists in the table, get its value 
	if (hm.containsKey(key) == true) {
		String retVal = hm.get(key);
		return retVal;
	}else{				
		// Otherwise, return "unknown key"
		String str = "Unknown Key";
		return str;
	}
    }

    public void shutdown() throws RemoteException  {
        try{
            // Unregister ourself
            Naming.unbind(serverName);
            // Unexport; this will also remove us from the RMI runtime
            UnicastRemoteObject.unexportObject(this, true);
            System.out.println("KVServer: exiting!");
        } catch(Exception e) {
            // too bad
        }
    }

    public static void main(String[] args) {

	// -------------BEGIN PROCESSBUILDER--------------

	String[] tokens = ("ps -o pid= -C rmiregistry").split("[ \t\n]+");

	ProcessBuilder pb = new ProcessBuilder(tokens);
	//pb.command("ps -o pid= -C rmiregistry");

	try {
    		Process p = pb.start();

		BufferedReader stdout = new BufferedReader(new InputStreamReader(p.getInputStream()));

		String output_line;
	 	output_line = stdout.readLine();

		// If no output, then start rmiregistry
    		if (output_line == null) {
			System.out.println("KVServer: Starting RMI Registry...");
			String[] tokens2 = ("rmiregistry").split("[ \t\n]+");
			ProcessBuilder pb2 = new ProcessBuilder(tokens2);
			Process p2 = pb2.start();

			// Sleep to allow rmiregistry enough time to start
			try {
				Thread.sleep(1000);
 			} catch (InterruptedException e) {}

			System.out.println("KVServer: RMI Registry started");

		// If there is output, then rmiregistry is already running
    		} else {
        		System.out.println("KVServer: RMI Registry already running!");
    		}

	} catch (IOException e) {
    		System.err.println(e.getMessage());
    		System.exit(1);
	}

	// -------------END PROCESSBUILDER--------------

        try {
            // Register myself to the RMI Registry
            System.err.println("KVServer: Registering to RMI Registry...");
            Naming.rebind(serverName, new KVServer2());
            System.err.println("KVServer: Registered to RMI Registry...");

        } catch (Exception e) {
            System.err.println("KVServer: exception: " + e.toString());
            e.printStackTrace();
            System.exit(0);
        }
    }
}
