ICS 332, Fall 2019 - Assignment 7 - Christian Cheshire
19 Nov 2019

Exercise #1

a. The logical page number is 2020/2048 = 0
   The offset is 2020 - (0 * 2048) = 2020
   The physical frame is 12 (from the page table provided) 
   So, the physical address is 12 * 2048 + 2020 = 26596

b. The logical page number is 12540/2048 = 6
   The page offset is 12540 - (6 * 2048) = 252
   The physical frame is 2 (from the page table provided)
   So, the physical address is 2 * 2048 + 252 = 4348

c. The logical page number is 8150/2048 = 3
   The page offset is 8150 - (3 * 2048) = 2006
   The physical frame is 6 (from the page table provided)
   So, the physical address is 6 * 2048 + 2006 = 14294

d. The logical page number is 22540/2048 = 11
   The page offset is 22540 - (11 * 2048) = 12
   The physical frame is 31 (from the page table provided)
   So, the physical address is 31 * 2048 + 12 = 63500

e. Logical address 32000 results in an error because:
   The logical page number is 32000/2048 = 15
   Which results in an error because the physical frame for
   logical page number 15 is invalid.

Exercise #2

a. There are 16 pages, which means the logical page number is 4-bits (since 2^4 = 16)
   There are 2^(12) bytes in one page, which means the offset is 12-bit
   Thus, the logical address is 16-bit.

b. There are 8 frames, which means the physical page number is 3 (since 2^3 = 8)
   There are 2^(12) bytes in one pages, which means the offset is 12-bit
   Thus, the physical address is 15-bit.

Exercise #3

a. 2^(2) * 2^(30) bytes physical memory, 2 * 2^(10) bytes page/frame size, 

   Address space has 4 GiB = 2^(30) * 2^(2) = 2^(32) bytes
   Page size is 2^(10) * 2(1) = 2^(11) bytes
   So, the address space can have 2^(32) / 2^(11) = 2^(21) pages
   and there would be 2^(21) entries in a single-level page table.

b. There are 2^(11) bytes frame size and there are 2^(21) frames in RAM.
   So, there would be 2^(32) / 2^(11) = 2^(21) entries in an inverted page table.

Exercise #4

a. The logical address size is 2^(44) bytes
   We know 64 KiB = 2^(16) bytes, because (2^(10) = 1 KiB * 2^(6) = 64)
   So, the page size is 2^(16) bytes, therefore there are 2^(44) / 2^(16) = 2^(28) pages

b. There are 64 KiB = 2^(16) bytes and the page size = 2^(16) bytes
   The offset is 16 bits, and each table entry is 4 bytes = 2^(2)
   So, the inner page is 2^(16) / 2^(2) = 2^(14) so 14 bits
   
   There are 2^(44) bytes for logical address, and the logical address is 2^(38) bytes
   So, there are 44 - 16 - 14 = 14 bits for outer page

c. 