ICS 332 - Assignment 1 - Christian Cheshire

EXERCISE #1
Answer the following questions:

[q1 (2pts)] What is the full absolute path to the standard C library file on your system? (since du is written in C, it should at some point open the standard C library�s .so file, which should have some easy-to-recognize name). Cut-and-paste into your report the line of strace�s output that shows the path to the standard C library.
open("/lib/x86_64-linux-gnu/libc.so.6", O_RDONLY|O_CLOEXEC) = 3


[q2 (3pts)] How many times does du try to open a file but fails? Explain how you counted this number (or just show your command-line if you used command-line tool to do this).
It failed 43 times. I copied the output into a text file and utilized the search function to count the number of times du failed to open a file (i.e. No such file or directory).


[q3 (3pts)] How many different system calls does du place? Explain how you made this determination? (this should be a number between 0 and 30).
It placed 21 different system calls. I determined this by manually tallying the different system calls listed in the terminal output.


[q4 (2pts)] Cut-and-paste the output of time (which will vary slightly from one invocation to the next, just pick one)
real    0m2.537s
user    0m0.412s
sys     0m1.092s


[q5 (3pts)] Based on the output of time, what percentage of the execution time of the du command is spent doing I/O? Show your work.
Real time = system time + user time + I/O time. 
Therefore I/O time is 2.537 - (0.412 + 1.092) = 1.033. 
Then, dividing 1.033 by 2.537, we get 0.40. 
Multiplying by 100%, we get 40%.


[q6 (3pts)] Based on the output of time and the strace output in previous question, how much CPU time, in microseconds, is spent on average to execute the instructions of a system call (counting only those calls that succeed)? Show your work.
Since the time output indicates 1.092s for system time and multiplying 1.092 x 10^6 to convert to 1092000 microseconds, we can simply divide that number by the number of system calls (21) to find the answer which is 52000 microseconds. 

-----------------------------------------------------------

Exercise #2
[q1 (3pts)] How many system calls are placed by wget before it receives the first bytes from the file content? Explain how you made that determination.
279 instances of systems calls are made before receiving the first bytes of file content. I determined this by using my text editor's search function (Ctrl-F) to find the first words of text from the file (i.e."The Project Gutenberg"). I then summed up all the systems calls executed previously.


[q2 (3pts)] How many bytes does wget typically attempts to read from the file at a time typically (e.g., the buffer size)? Justify your answer by giving in your report one line of the strace output as an example.
Typically wget attempts to read 8192 bytes into the buffer each time. This can be seen from the following line of strace output: read(3, " reigning family of Holland. Bey"..., 8192) = 8192


[q3 (3pts)] How many times does wget attempt to read pieces of file content, in total? Explain how you made that determination.
2140 times. Using the search function of my text editor, I found all instances of the read system call (i.e read(int fd, void *buf, size_t count)). Then, again using the search function, found and deleted all the instances of read that did not involve reading of text from the file, leaving the 2140 instances in which wget was reading file content.


[q4 (3pts)] Out of these, how many times the read system call does NOT receive the number of bytes it wants? Explain how you made this determination.
To do this I took the number of times the read system call read pieces of file content. Then I found all the instances of read getting the exact number of bytes it requested (again using the search function of my text editor) which was 194 times. Thus, using subtraction 2140-194 = 1946. Therefore, this is the number of times the read system call did not get the exact number of bytes requested.


[q5 (2pts)] Do you conclude that wget typically fills its buffer or not?
Based on my calculations, wget does not typically fill its buffer, since read usually requests more bytes than it receives.


[q6 (3pts)] How many times does wget attempt to read pieces of file content, in total?
It attempts to read pieces of the file 1958 times total.


[q7 (3pts)] Out of these, how many times read does NOT receive the number of bytes it wants?
It does not receive the number of bytes it wants 1750 times.


[q8 (2pts)] Do you conclude that wget typically fills its buffer or not?
Typically it does not because out of 1958 calls for read, it only received the number of bytes wanted 208 times.


[q9 (2pts)] Why do you think results are different than in the previous experiment?
Primarily, I think it is due to non-determinism. Because wget does not always fill its buffer, the read system call gets different numbers of bytes for each line of file content each time the wget command is run.

