package rmiexample;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.rmi.Naming;


public class Client {

    // The handle to the remote server
    private static MyRMIInterface server_handle;

    public static void main(String[] args)  {

        String string_input;
        int integer_input;

        // Get a console to read from the keyboard
        BufferedReader console = new BufferedReader(new InputStreamReader(System.in));

        try {
            // Looking up the remote server
            System.err.println("Looking up the RMI Registry to locate the server...");
            server_handle = (MyRMIInterface) Naming.lookup("rmi://localhost/Server");

            System.err.println("Server successfully located and handle obtqined!");
            while(true) {

                // Get user input
                System.err.print("Enter an integer increment: ");
                string_input = console.readLine();
                
                // If EOF (i.e., ^D), terminate
                if (string_input == null) {
                    break;
                } 

                // Parse to an integer (if not an integer, try again)
                try {
                    integer_input = Integer.parseInt(string_input); 
                } catch (NumberFormatException e) {
                    continue;
                }

                // Place the RMI
                System.err.print("Placing an RMI to the server... ");
                int response = server_handle.increment(integer_input);
                System.err.println("who successfully replied " + response + "!");
            }
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
            System.exit(0);
        }
    }
}
