package rmiexample;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Server extends UnicastRemoteObject implements MyRMIInterface {

    // An integer counter
    private int counter = 0;

    // Custom constructor that throws the required exception
    protected Server() throws RemoteException {
        super();
    }

    // Method that clients can call via RMI
    //@Override
    public int increment(int x) throws RemoteException {
        this.counter += x;
        System.err.println("Somebody has incremented my counter by " + x + "!");
        return this.counter;
    }

    public static void main(String[] args) {

        try {
            // Register myself to the RMI Registry
            System.err.println("Contacting the RMI Registry to register myself...");
            Naming.rebind("rmi://localhost/Server", new Server());
            System.err.println("Server registered and ready for RPC calls!");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
            System.exit(0);
        }
    }
}

