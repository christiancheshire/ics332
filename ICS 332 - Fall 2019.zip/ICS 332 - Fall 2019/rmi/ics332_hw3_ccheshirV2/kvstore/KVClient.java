package kvstore;

import java.rmi.Naming;

public class KVClient {

    // Handle to the remote server
    private static KVInterface server_handle;

    public static void main(String[] args)  {

      try {
        // Look up the remote server
        server_handle = (KVInterface) Naming.lookup("rmi://localhost/Server");

        while(true) {

	  // if no input is provided, return and print usage requirements
          if (args[0] == null) {
		return;
	  }

          // shutdown the server
          if (args[0].equals("shutdown") && args.length == 1) {
          	server_handle.shutdown();
            	return;
	  // insert the key and value
          } else if (args[0].equals("insert") && args.length == 3) {
      		server_handle.insert(args[1], args[2]);
      		return;
	  // lookup the key
      	  } else if (args[0].equals("lookup") && args.length == 2) {
      		String result = server_handle.lookup(args[1]);
      		System.err.println(result);
      		return;
      	  } else {
            throw new Exception("");
          }

        }

      } catch (Exception e) {
            System.err.println("Usage: java kvstore.KVClient [ shutdown | insert <key> <value> | lookup <key> ]");
            System.exit(0);
      }
    }
}
