package kvstore;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.InterruptedException;
import java.io.InputStream;

public class KVServer2 extends UnicastRemoteObject implements KVInterface {

    private static final String serverName = "rmi://localhost/Server";

    // Custom constructor that throws the required exception
    protected KVServer2() throws RemoteException {
        super();
    }

    // Create a new hashmap
    HashMap<String,String> hm = new HashMap<String,String>();

    @Override
    public void insert(String key, String value) throws RemoteException {
      try {


        if (hm.containsKey(key) == true) {	// If the key already exists in the table, replace the value for that key
		        hm.replace(key,value);
	      }
        else {					// Otherwise, insert the key and value
		        hm.put(key,value);
	      }
      } catch (Exception e) {

      }
    }

    @Override
    public String lookup(String key) throws RemoteException, KeyNotFound {
        if (hm.containsKey(key) == true) {	// If the key exists in the table, get its value
		String retVal = hm.get(key);
		return retVal;
	}else{					// Otherwise, return "unknown key"
		String str = "Unknown Key";
		return str;
	}
    }

    public void shutdown() throws RemoteException  {
        try{
            // Unregister ourself
            Naming.unbind(serverName);
            // Unexport; this will also remove us from the RMI runtime
            UnicastRemoteObject.unexportObject(this, true);
            System.out.println("KVServer: exiting!");
        } catch(Exception e) {
            // too bad
        }
    }

    public static void main(String[] args) {

	String[] tokens = ("ps -o pid= -C rmiregistry").split("[ \t\n]+");
        String[] tokens2 = ("rmiregistry").split("[ \t\n]");
	ProcessBuilder pb = new ProcessBuilder(tokens);
        ProcessBuilder pb2 = new ProcessBuilder(tokens2);
        Process p = null;
        Process p2 = null;

        try {
          p = pb.start();

          InputStream  sstdout = p.getInputStream();
          BufferedReader stdout = new BufferedReader(new InputStreamReader(sstdout));

          String output_line;

              output_line = stdout.readLine();
              if (output_line == null) {
                  System.out.println("KVServer: Starting RMI Registry...");
                  p2 = pb2.start();
                  try {
                    Thread.sleep(1500);
                  } catch (InterruptedException e) {

                  }

                  System.out.println("KVServer: RMI Registry Started");
              } else {
                  System.out.println("KVServer: RMI Registry already running!");
              }
        } catch(IOException e) {
          System.err.println(e.getMessage());
          System.exit(1);
        }

	 try {
            // Register myself to the RMI Registry
            System.err.println("KVServer: Registering to RMI Registry...");
            Naming.rebind(serverName, new KVServer2());
            System.err.println("KVServer: Registered to RMI Registry...");
        } catch (Exception e) {
            System.err.println("KVServer: exception: " + e.toString());
            e.printStackTrace();
            System.exit(0);
        }


    }
}
