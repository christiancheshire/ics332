package fswatcher;

public class FSWatcherQ1 {

    public void watch(String dirname, Consumer<String> method) {
	
    }
}
