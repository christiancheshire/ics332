ICS 332 - Fall 2019
Assignment 2
Christian Cheshire

Exercise #1

[q1 (5 pts)] Explain why the main process is not blocked while the cp process is running.

Because the child program is terminated because it's return value from fork() is not 0. Thus, the wait() command is fulfilled and the grand-child executes.

[q2 (8 pts)] Explain why no zombie is left over by this program.

Because PID 1 doesn't leave any zombies, as it acknowledges all of its children's deaths. Also the child and grand-child processes are terminated by the exit command and wait() forces the main program to wait until the child completes, which ensures that it doesn't become a zombie because a zombie only exists when it's parent doesn't acknowledge its termination.

Exercise #2

q1 [3 pts]: At what time is �** ONE **� printed to the terminal?

40s

q2 [3 pts]: At what time is �** TWO **� printed to the terminal?

50s

q3 [3 pts]: What is the PID of the process that prints �** TWO **�?

11

q4 [3 pts]: What is the PPID of the process with PID 89?

11

q5 [3 pts]: At what time does the process with PID 123 terminate?

30s

q6 [3 pts]: At what time would �** TWO**� be printed if line 25 were removed?

20s

q7 [3 pts]: Give the PID of a process that is a zombie at the time when �** TWO **� is being printed

89

q8 [3 pts]: Give the PID of a non-zombie process that at some point in the execution becomes an orphan

11

q9 [3 pts]: Which processes are �alive� (i.e., not terminated nor zombies) right before process with PID 123 terminates (PID 123 is thus one of these)?

11, 89, 123