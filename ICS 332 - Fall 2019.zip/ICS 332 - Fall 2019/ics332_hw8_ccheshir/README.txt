ICS 332 Assignment 8, Fall 2019, Christian Cheshire
27 Nov 2019

Exercise #1

a. Optimal:

  | 0  1  7  2  0  3  1  7  0  1  7 
------------------------------------
0 | 0  0  0  0  0  0  0  0  0  0  0
1 | -  1  1  1  1  1  1  1  1  1  1
2 | -  -  7  7  7  7  7  7  7  7  7 
3 | -  -  -  2  2  3  3  3  3  3  3
------------------------------------
f | X  X  X  X  -  X  -  -  -  -  -

So, there are 5 page faults.


b. FIFO:

  | 0  1  7  2  0  3  1  7  0  1  7 
------------------------------------
0 | 0  0  0  0  0  3  3  3  3  3  3
1 | -  1  1  1  1  1  1  1  0  0  0
2 | -  -  7  7  7  7  7  7  7  1  1 
3 | -  -  -  2  2  2  2  2  2  2  7
------------------------------------
f | X  X  X  X  -  X  -  -  X  X  X

So, there are 8 page faults.


c. LRU:

  | 0  1  7  2  0  3  1  7  0  1  7 
------------------------------------
0 | 0  0  0  0  0  0  0  0  0  0  0
1 | -  1  1  1  1  3  3  3  3  3  3
2 | -  -  7  7  7  7  1  1  1  1  1 
3 | -  -  -  2  2  2  2  7  7  7  7
------------------------------------
f | X  X  X  X  -  X  X  X  -  -  -

So, there are 7 page faults.


Exercise #2

So, based on the given values

400ns = (1 - 0.00003)*(100ns) + (0.00003)*(6ms + d * 6ms)

If we solve for d, we get 0.667 which is about a 66.7 percent chance.
